TravelSmart24 Travels & Tourism — Hostinger Upload Instructions
=================================================================

This package contains a single, self-contained website file:

    index.html

It has no separate images, CSS, or JS files — everything (fonts link
aside) is built into that one file, so there is nothing else to
upload alongside it.

HOW TO GO LIVE ON HOSTINGER
----------------------------
1. Log in to Hostinger's hPanel.
2. Go to Files > File Manager (or connect via FTP using the
   credentials in hPanel > Files > FTP Accounts).
3. Open the "public_html" folder for your domain.
   - If you see a default "index.html" or "index.php" already there
     (a placeholder / parked-domain page), delete or rename it first
     so it doesn't conflict.
4. Upload "index.html" from this package directly into public_html
   (drag-and-drop works in File Manager, or use "Upload Files").
5. Visit your domain in a browser (give it a minute or two if the
   domain was only just pointed to Hostinger / DNS is still
   propagating). The site should load immediately — no build step,
   database, or server configuration is required.

NOTES
-----
- The page pulls two Google Fonts ("Fraunces" and "Work Sans") from
  Google's font CDN over HTTPS. No action needed — this works out of
  the box on any standard Hostinger hosting plan with outbound
  internet access, which is the default.
- The Mysore Palace photo and all destination art are embedded
  directly in the HTML as data, so there's no /images folder to
  upload separately.
- All contact details, phone/WhatsApp numbers, package prices, and
  copy are placeholders based on the brief — edit index.html directly
  (search for the relevant text) to update anything before or after
  going live.
- If you later want to add pages (e.g. a dedicated Contact page or
  individual package detail pages), just add more .html files into
  the same public_html folder and link to them from the nav.
